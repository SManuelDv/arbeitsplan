---
name: "✨ Nova Feature"
about: "Sugerir uma nova funcionalidade"
title: "feat: "
labels: ["enhancement"]
assignees: ""
---

## Descrição da Feature
[Descreva a feature aqui]

## Motivação
[Por que esta feature é necessária?]

## Comportamento Esperado
[Como você espera que funcione?]

## Checklist
- [ ] Alinhado com objetivos do projeto
- [ ] Implementação viável
- [ ] Documentação necessária
